this crud app basically reads from the iceandfire api
#its required that this project is ran over an inetrnet connection cos
#this projects import a list of cdns like the sweetalert cdn, for basic functionalities
#setting up this project only requires a basic understanding of npm and composer
#npm helps setup the react enviroment while composer installs various Laravel depencies to get you up and running
#this app can be made better, but for time's sake, this will be my first deployment to git
Thanks
